using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemy_ai : MonoBehaviour
{
    Rigidbody2D rigid;
    Animator anim;
    SpriteRenderer spriteRenderer;

    //객체 단위로 설정하는 변수 ex)HP, Atk ...
    public int hp, atk_dmg;
    public int speed;
    public Transform target;
    public float chase_dis, attack_dis, patrol_limit;
    public Transform pos;
    public Vector2 boxSize;
    public float attack_speed;
    public Transform hpBar;

    //객체 단위로 설정하면 안되는 변수
    public int nextMove;
    public float dis, start_x;
    public float nextThinkTime;
    public bool dying, attacked, attacking;
    public float atk_delay;

    void Awake()
    {
        rigid = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        dying = false;
        anim.SetBool("isAttacking", false);
        start_x = transform.position.x;

        Think();
    }

    void FixedUpdate()
    {
        atk_delay -= Time.deltaTime;
        if(atk_delay < 0) atk_delay = 0;
        dis = Vector3.Distance(transform.position, target.position);

        anim.SetInteger("walkSpeed", nextMove);

        if(nextMove != 0)
            if (nextMove > 0)
                spriteRenderer.flipX = false;
            else
                spriteRenderer.flipX = true;

        if(!dying && atk_delay==0)
        {
            anim.SetBool("isAttacking", false);
            
            if(dis>chase_dis)//추적 범위 밖에 있으면 패트롤
            {
                if(!IsInvoking("Think"))
                {
                    Think();
                }
                rigid.velocity = new Vector2(nextMove*speed, rigid.velocity.y);
            }
            else if(dis<=chase_dis)
            {
                Chase();
            }
        }
    }

    void Think()//패트롤시 이동 방향을 무작위로 정하게 하는 함수
    {
        nextMove = Random.Range(-2, 3);
        nextThinkTime = Random.Range(0.5f, 2f);

        if(transform.position.x > start_x + patrol_limit || transform.position.x < start_x - patrol_limit)
        {
            if(transform.position.x > start_x + patrol_limit)
            {
                nextMove = -2;
            }
            if(transform.position.x < start_x - patrol_limit)
            {
                nextMove = 2;
            }
        }

        Invoke("Think",nextThinkTime);
    }

    void Chase()
    {
        CancelInvoke();
        if(transform.position.x > target.position.x)//추적 대상이 왼쪽에 있을때
        {
            rigid.velocity = new Vector2(-2*speed, rigid.velocity.y);
            nextMove = -2;
        }
        else//추적 대상이 오른쪽에 있을때
        {
            rigid.velocity = new Vector2(2*speed, rigid.velocity.y);
            nextMove = 2;
        }

        if(dis<=attack_dis)
        {
            Attack();
        }
    }

    public void Attack()
    {
        anim.SetBool("isAttacking", true);

        atk_delay = attack_speed;

        Collider2D[] collider2Ds = Physics2D.OverlapBoxAll(pos.position, boxSize, 0);

        foreach(Collider2D collider in collider2Ds)
        {
            if(collider.tag == "Player" && !attacked)
            {
                collider.GetComponent<Move>().TakeDamage(10);
            }
        }
    }

    public void TakeDamage(int dmg)
    {
        hp = hp - dmg;
        if(hp <= 0)
        {
            dying = true;
            CancelInvoke();
            anim.SetTrigger("isDying");
            Destroy(this.gameObject, 0.55f);
        }
    }

    private void OnDrawGizmos()//공격 범위 가시화
    {
        Gizmos.color = Color.blue;
        Gizmos.DrawWireCube(pos.position, boxSize);
    }
}
