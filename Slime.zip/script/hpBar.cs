using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class hpBar : MonoBehaviour
{
    public GameObject obj;
    float maxHp, nowHp;

    // Start is called before the first frame update
    void Awake()
    {
        maxHp = obj.GetComponent<enemy_ai>().hp;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        nowHp = obj.GetComponent<enemy_ai>().hp;

        transform.localScale = new Vector3((nowHp/maxHp)*0.07f, transform.localScale.y, 0);
    }
}
